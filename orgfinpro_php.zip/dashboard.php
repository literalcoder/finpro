<?php
include 'functions.php';
requireLogin();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">OrgFinPro</a>
    <div class="d-flex">
      <span class="text-white me-3">Hello, <?php echo $_SESSION['name']; ?></span>
      <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">
  <h2>Dashboard</h2>
  <div class="row mt-4">
    <div class="col-md-4">
      <div class="card text-bg-primary mb-3">
        <div class="card-body">
          <h5 class="card-title">Proposals</h5>
          <p class="card-text">View and manage proposals.</p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-bg-success mb-3">
        <div class="card-body">
          <h5 class="card-title">Finances</h5>
          <p class="card-text">Track income and expenses.</p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-bg-warning mb-3">
        <div class="card-body">
          <h5 class="card-title">Reports</h5>
          <p class="card-text">Generate terminal reports.</p>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>